package com.capg.project.Exception;

public class BillException extends RuntimeException{

}
