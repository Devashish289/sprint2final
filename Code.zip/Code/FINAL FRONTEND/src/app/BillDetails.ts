export class BillDetails{
      private  billNo:number;
      private   holderName:String;
      private connectionCode :String;
      private  billAmount:String;
 

}