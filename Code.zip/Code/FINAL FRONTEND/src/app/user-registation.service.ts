import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserRegistationService {
  deleteBillDetails(id: number) {
    throw new Error("Method not implemented.");
  }

  constructor(private http:HttpClient) { }


  public doRegistration(BillDetails){
    alert('Your bill registered successfully..')
    return this.http.post<any>("http://localhost:8088/register",BillDetails);
  }

  public viewAccountById(billNo){
    return this.http.get("http://localhost:8088/viewAccountById/"+billNo);
  }
  
  public paynow(){
    alert("Thank you, You are being redirected to payment page...");
  }
}
