import { Component, OnInit } from '@angular/core';
import { UserRegistationService } from '../user-registation.service';
import { BillDetails } from '../BillDetails';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {


  BillDetails: BillDetails=new BillDetails();
  message:any;
  router: any;

  constructor(private service:UserRegistationService) { }

  ngOnInit() {
  }
  

public registerNow(){
let resp=this.service.doRegistration(this.BillDetails);
resp.subscribe((data)=>this.message=data);
};
  }
